
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata = {
  title: "SMA Negeri 1 Purworejo",
  description:
    "Situs resmi SMA Negeri 1 Purworejo. Unggul, Berkarakter, Mendunia.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body className="min-h-screen bg-white text-slate-900 antialiased">
        <Navbar />

        {children}

        <Footer />
      </body>
    </html>
  );
}
